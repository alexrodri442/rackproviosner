"""Application settings and local inventory builder UI.

Layer rule: this module should depend only on lower-level modules documented in ARCHITECTURE.md.
"""

from PySide6.QtWidgets import QWidget,QVBoxLayout,QFormLayout,QCheckBox,QComboBox,QGroupBox,QLineEdit,QHBoxLayout,QLabel,QPushButton,QMessageBox
class SettingsPage(QWidget):
    def __init__(self,settings,inventory,bus):
        super().__init__(); self.settings=settings; self.inventory=inventory; self.bus=bus; c=settings.load(); l=QVBoxLayout(self); f=QFormLayout(); self.engineer=QCheckBox(); self.engineer.setChecked(c.getboolean("general","engineer_mode",fallback=False)); self.inv=QCheckBox(); self.inv.setChecked(c.getboolean("inventory","enabled",fallback=False)); self.imp=QCheckBox(); self.imp.setChecked(c.getboolean("inventory","enable_file_import",fallback=False)); self.start=QComboBox(); self.start.addItems(["single_switch","multi_switch"]); self.start.setCurrentText(c.get("general","startup_page",fallback="single_switch")); self.baud=QComboBox(); self.baud.addItems(["9600","19200","38400","57600","115200"]); self.baud.setCurrentText(c.get("general","default_baud",fallback="9600"))
        for n,w in [("Engineer Mode",self.engineer),("Enable Inventory",self.inv),("Enable CSV/JSON Import (future parser)",self.imp),("Startup Page",self.start),("Default Baud",self.baud)]: f.addRow(n,w)
        l.addLayout(f); g=QGroupBox("Inventory Builder"); z=QFormLayout(g); self.rs=QLineEdit(); self.sku=QLineEdit(); self.bom=QLineEdit(); self.asset=QLineEdit(); z.addRow("Rack Serial",self.rs); z.addRow("Rack SKU",self.sku); z.addRow("Rack BOM",self.bom); z.addRow("Rack Asset Tag",self.asset); self.devices={}
        for role in ("MX","NS1","NS2"):
            m=QLineEdit(); s=QLineEdit(); a=QLineEdit(); self.devices[role]=(m,s,a); row=QHBoxLayout(); row.addWidget(QLabel(role)); row.addWidget(QLabel("Model")); row.addWidget(m); row.addWidget(QLabel("Serial")); row.addWidget(s); row.addWidget(QLabel("MAC")); row.addWidget(a); z.addRow(row)
        bi=QPushButton("Save Inventory Record"); z.addRow(bi); l.addWidget(g); bs=QPushButton("Save Settings"); l.addWidget(bs); l.addStretch(); bi.clicked.connect(self.save_inventory); bs.clicked.connect(self.save)
    def save_inventory(self):
        if not self.rs.text().strip() or not self.sku.text().strip(): QMessageBox.warning(self,"Inventory","Rack Serial and SKU are required."); return
        ds=[{"role":r,"model":m.text(),"serial":s.text(),"mac":a.text()} for r,(m,s,a) in self.devices.items()]; self.inventory.save_record({"rack_serial":self.rs.text().strip(),"rack_sku":self.sku.text().strip(),"rack_bom":self.bom.text(),"rack_asset_tag":self.asset.text()},ds); QMessageBox.information(self,"Inventory","Saved.")
    def save(self):
        c=self.settings.load(); c.set("general","engineer_mode",str(self.engineer.isChecked()).lower()); c.set("general","startup_page",self.start.currentText()); c.set("general","default_baud",self.baud.currentText()); c.set("inventory","enabled",str(self.inv.isChecked()).lower()); c.set("inventory","enable_file_import",str(self.imp.isChecked()).lower()); self.settings.save(c); self.bus.publish("settings.changed"); QMessageBox.information(self,"Settings","Saved.")
